const config = {
    db: {
        host: "localhost",
        user: "root",
        password: "",
        database: "aproject",
        connectTimeout: 60000
    }
};
 
module.exports = config;